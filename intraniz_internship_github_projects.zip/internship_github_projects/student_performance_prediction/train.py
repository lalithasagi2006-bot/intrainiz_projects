"""Train and evaluate a student-performance model from a CSV file."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    mean_absolute_error, mean_squared_error, r2_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def infer_task(target: pd.Series) -> str:
    """Infer task type; pass --task explicitly when this inference is unsuitable."""
    if pd.api.types.is_numeric_dtype(target):
        unique_count = target.nunique(dropna=True)
        # Numeric marks/scores are treated as regression targets.
        return "regression" if unique_count > 15 else "classification"
    return "classification"


def build_pipeline(X: pd.DataFrame, task: str) -> Pipeline:
    numeric_cols = X.select_dtypes(include=["number"]).columns.tolist()
    categorical_cols = [c for c in X.columns if c not in numeric_cols]

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocess = ColumnTransformer([
        ("numeric", numeric_pipeline, numeric_cols),
        ("categorical", categorical_pipeline, categorical_cols),
    ])

    if task == "regression":
        model = RandomForestRegressor(
            n_estimators=300, random_state=42, n_jobs=-1
        )
    else:
        model = RandomForestClassifier(
            n_estimators=300, random_state=42, class_weight="balanced", n_jobs=-1
        )

    return Pipeline([("preprocess", preprocess), ("model", model)])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, help="Path to input CSV file")
    parser.add_argument("--target", required=True, help="Target column to predict")
    parser.add_argument(
        "--task", choices=["auto", "regression", "classification"], default="auto"
    )
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--output-dir", default="outputs")
    args = parser.parse_args()

    data_path = Path(args.data)
    if not data_path.exists():
        raise FileNotFoundError(f"Dataset not found: {data_path}")

    df = pd.read_csv(data_path)
    if args.target not in df.columns:
        raise ValueError(
            f"Target '{args.target}' not found. Available columns: {list(df.columns)}"
        )

    df = df.dropna(subset=[args.target]).copy()
    if len(df) < 10:
        raise ValueError("At least 10 rows with a non-missing target are recommended.")

    y = df[args.target]
    X = df.drop(columns=[args.target])

    # Drop obvious identifier columns; inspect and adjust this list for your dataset.
    id_like = [
        col for col in X.columns
        if col.strip().lower() in {"id", "student_id", "studentid", "name", "email"}
    ]
    if id_like:
        X = X.drop(columns=id_like)
        print(f"Dropped identifier-like columns: {id_like}")

    if X.shape[1] == 0:
        raise ValueError("No feature columns remain after removing the target/identifiers.")

    task = infer_task(y) if args.task == "auto" else args.task
    if task == "classification" and y.nunique() < 2:
        raise ValueError("Classification requires at least two target classes.")

    stratify = y if task == "classification" and y.value_counts().min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=42, stratify=stratify
    )

    pipeline = build_pipeline(X_train, task)
    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)

    if task == "regression":
        metrics = {
            "task": task,
            "rows_used": int(len(df)),
            "features_used": list(X.columns),
            "mae": float(mean_absolute_error(y_test, predictions)),
            "rmse": float(np.sqrt(mean_squared_error(y_test, predictions))),
            "r2": float(r2_score(y_test, predictions)),
        }
    else:
        metrics = {
            "task": task,
            "rows_used": int(len(df)),
            "features_used": list(X.columns),
            "accuracy": float(accuracy_score(y_test, predictions)),
            "classification_report": classification_report(
                y_test, predictions, output_dict=True, zero_division=0
            ),
            "confusion_matrix": confusion_matrix(y_test, predictions).tolist(),
        }

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    result = pd.DataFrame({
        "actual": y_test.reset_index(drop=True),
        "predicted": pd.Series(predictions),
    })
    result.to_csv(output_dir / "predictions.csv", index=False)
    with open(output_dir / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, default=str)
    joblib.dump(pipeline, output_dir / "model.joblib")

    print(json.dumps(metrics, indent=2, default=str))
    print(f"\nSaved model and evaluation files to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()
