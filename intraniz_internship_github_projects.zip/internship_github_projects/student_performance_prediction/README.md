# Student Performance Prediction Using Machine Learning

A reusable supervised-learning pipeline for predicting student performance from an anonymized CSV dataset.

## Run

```bash
python train.py --data data/student_performance.csv --target final_score
```

Use `--task regression` for numeric marks or `--task classification` for categories such as `Pass`/`Fail`. The default `auto` mode makes a simple inference from the target values.

The script uses a held-out test set and a preprocessing pipeline:
- Missing numeric values: median imputation
- Missing categorical values: most-frequent imputation
- Categorical features: one-hot encoding
- Numeric features: standard scaling
- Candidate model: Random Forest (regressor or classifier)

For trustworthy results, verify the target, remove identifiers and leakage columns, and use a representative dataset.
