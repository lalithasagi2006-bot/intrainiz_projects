Place your permitted customer dataset CSV in this folder. The default expected columns are Age, Annual Income (k$), and Spending Score (1-100).
