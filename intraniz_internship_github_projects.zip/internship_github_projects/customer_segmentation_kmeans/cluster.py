"""Perform customer segmentation with K-Means clustering."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler


DEFAULT_FEATURES = ["Age", "Annual Income (k$)", "Spending Score (1-100)"]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, help="Path to customer CSV")
    parser.add_argument(
        "--features",
        default=",".join(DEFAULT_FEATURES),
        help="Comma-separated numeric feature columns",
    )
    parser.add_argument("--min-k", type=int, default=2)
    parser.add_argument("--max-k", type=int, default=10)
    parser.add_argument("--output-dir", default="outputs")
    args = parser.parse_args()

    data_path = Path(args.data)
    if not data_path.exists():
        raise FileNotFoundError(f"Dataset not found: {data_path}")

    df = pd.read_csv(data_path)
    features = [name.strip() for name in args.features.split(",") if name.strip()]
    missing = [name for name in features if name not in df.columns]
    if missing:
        raise ValueError(
            f"Missing feature columns: {missing}. Available columns: {list(df.columns)}"
        )

    numeric = df[features].apply(pd.to_numeric, errors="coerce")
    valid_mask = numeric.notna().all(axis=1)
    if valid_mask.sum() < 4:
        raise ValueError("At least 4 rows with complete numeric feature values are required.")

    X = numeric.loc[valid_mask]
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    upper_k = min(args.max_k, len(X) - 1)
    if args.min_k < 2 or upper_k < args.min_k:
        raise ValueError("Choose a valid K range with min-k >= 2 and max-k >= min-k.")

    comparison = []
    fitted_models = {}
    for k in range(args.min_k, upper_k + 1):
        model = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = model.fit_predict(X_scaled)
        score = silhouette_score(X_scaled, labels)
        comparison.append({
            "k": k,
            "inertia": float(model.inertia_),
            "silhouette_score": float(score),
        })
        fitted_models[k] = (model, labels)

    comparison_df = pd.DataFrame(comparison)
    best_k = int(comparison_df.loc[comparison_df["silhouette_score"].idxmax(), "k"])
    best_model, best_labels = fitted_models[best_k]

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    output = df.loc[valid_mask].copy()
    output["cluster"] = best_labels
    output.to_csv(output_dir / "customers_with_clusters.csv", index=False)

    profiles = output.groupby("cluster")[features].agg(["count", "mean", "median"])
    profiles.to_csv(output_dir / "cluster_profiles.csv")
    comparison_df.to_csv(output_dir / "k_comparison.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    axes[0].plot(comparison_df["k"], comparison_df["inertia"], marker="o")
    axes[0].set_title("Elbow Method")
    axes[0].set_xlabel("Number of clusters (K)")
    axes[0].set_ylabel("Inertia")

    axes[1].plot(
        comparison_df["k"], comparison_df["silhouette_score"], marker="o"
    )
    axes[1].set_title("Silhouette Score")
    axes[1].set_xlabel("Number of clusters (K)")
    axes[1].set_ylabel("Silhouette score")

    fig.tight_layout()
    fig.savefig(output_dir / "elbow_silhouette.png", dpi=160)
    plt.close(fig)

    print(f"Selected K by silhouette score: {best_k}")
    print(f"Rows clustered: {len(output)}")
    print(f"Saved results to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()
