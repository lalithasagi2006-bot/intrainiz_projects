# Customer Segmentation Using K-Means Clustering

This project scales selected customer attributes, compares candidate cluster counts, fits K-Means, and exports customer cluster labels and cluster profiles.

## Run

```bash
python cluster.py --data data/Mall_Customers.csv
```

Default features:
- `Age`
- `Annual Income (k$)`
- `Spending Score (1-100)`

For a CSV with different names:

```bash
python cluster.py --data data/customers.csv --features age,income,spending_score
```

The script selects K using the highest silhouette score among the tested values (2 through 10, subject to dataset size). Review the elbow and silhouette chart and business meaning before finalizing K.
