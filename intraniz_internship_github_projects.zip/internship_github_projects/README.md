# Intraniz Internship Projects — Data Science

This repository contains two starter implementations matching the projects described in the internship report:

1. **Student Performance Prediction Using Machine Learning** — supervised learning for a numeric or categorical student-performance target.
2. **Customer Segmentation Using K-Means Clustering** — unsupervised grouping of customers using selected numeric features.

## Requirements

- Python 3.9+
- Install dependencies:

```bash
pip install -r requirements.txt
```

## Project 1: Student Performance Prediction

1. Put your approved/anonymized student dataset CSV in `student_performance_prediction/data/`.
2. Identify the target column (for example, `final_score` or `performance_category`).
3. Run:

```bash
python student_performance_prediction/train.py \
  --data student_performance_prediction/data/student_performance.csv \
  --target final_score
```

The script infers regression versus classification from the target column. You can override it with `--task regression` or `--task classification`.

Outputs are written to `student_performance_prediction/outputs/`:
- `metrics.json`
- `predictions.csv`
- `model.joblib`

## Project 2: Customer Segmentation

1. Put your customer CSV in `customer_segmentation_kmeans/data/`.
2. By default, the script looks for columns named `Age`, `Annual Income (k$)`, and `Spending Score (1-100)`.
3. Run:

```bash
python customer_segmentation_kmeans/cluster.py \
  --data customer_segmentation_kmeans/data/Mall_Customers.csv
```

If your column names differ, provide them:

```bash
python customer_segmentation_kmeans/cluster.py \
  --data customer_segmentation_kmeans/data/customers.csv \
  --features age,annual_income,spending_score
```

Outputs are written to `customer_segmentation_kmeans/outputs/`:
- `customers_with_clusters.csv`
- `cluster_profiles.csv`
- `k_comparison.csv`
- `elbow_silhouette.png`

## Important notes

- The scripts do not include a private or institution-owned dataset. Use only datasets you are permitted to use, and document the dataset source and licence.
- Remove names, contact details, student IDs, and other unnecessary personal identifiers before training.
- The scripts generate results from the CSV you provide. Do not report example metrics or cluster interpretations as actual findings until you run the code.
- Add screenshots of your own execution to the repository only after running the projects.
